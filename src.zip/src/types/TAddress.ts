type Address = {
    address: string;
    city: string;
    state: string;
    pin: string;
}

export default Address;